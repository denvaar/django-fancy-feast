from .widgets import DataModelChoice

__all__ = [
    DataModelChoice
]

