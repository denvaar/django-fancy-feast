==================
Django Fancy Feast
==================

Django Fancy Feast is a collection of handy things for Django.

Quick Start
-----------

1. Add 'django-fancy-feast' to your INSTALLED_APPS setting::

    INSTALLED_APPS = [
        ...
        'django-fancy-feast',
    ]


